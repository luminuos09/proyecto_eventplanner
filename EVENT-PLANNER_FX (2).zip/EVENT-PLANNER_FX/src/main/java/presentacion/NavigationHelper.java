package presentacion;

import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import java.net.URL;

/**
 * Clase auxiliar para manejar navegación y estilos.
 * 
 * @author Ayner Jose Castro Benavides
 * @version 1.0
 */
public class NavigationHelper {
    
    private static final String CSS_PATH = "/fxml/styles.css";
    
    /**
     * Aplica el CSS a una escena
     * 
     * @param scene Escena a la que aplicar CSS
     */
    public static void aplicarCSS(Scene scene) {
        URL cssLocation = NavigationHelper.class.getResource(CSS_PATH);
        
        if (cssLocation != null) {
            String cssUrl = cssLocation.toExternalForm();
            
            // Evitar duplicados
            if (!scene.getStylesheets().contains(cssUrl)) {
                scene.getStylesheets().add(cssUrl);
                System.out.println("[NavigationHelper] CSS aplicado correctamente");
            }
        } else {
            System.out.println("[NavigationHelper] Advertencia: CSS no encontrado en " + CSS_PATH);
        }
    }
    
    /**
     * Aplica CSS, maximiza y ajusta al tamaño de pantalla
     * 
     * @param scene Escena a la que aplicar CSS
     * @param stage Stage a maximizar
     */
    public static void aplicarCSSyMaximizar(Scene scene, Stage stage) {
        aplicarCSS(scene);
        
        // Ajustar al tamaño de la pantalla
        javafx.stage.Screen screen = javafx.stage.Screen.getPrimary();
        javafx.geometry.Rectangle2D bounds = screen.getVisualBounds();
        
        stage.setWidth(bounds.getWidth());
        stage.setHeight(bounds.getHeight());
        stage.setX(0);
        stage.setY(0);
        
        stage.setMaximized(true);
        agregarAtaljoF11(scene, stage);
    }
    
    /**
     * Agrega el atajo F11 para alternar pantalla completa
     * 
     * @param scene Escena
     * @param stage Stage
     */
    public static void agregarAtaljoF11(Scene scene, Stage stage) {
        scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.F11) {
                stage.setFullScreen(!stage.isFullScreen());
                event.consume();
            }
        });
    }
    /**
 * Configura una escena completa (CSS, maximizado, F11)
 * 
 * @param stage Stage donde aplicar la configuración
 */
public static void configurarEscena(Stage stage) {
    Scene scene = stage.getScene();
    if (scene != null) {
        aplicarCSS(scene);
        agregarAtaljoF11(scene, stage);
    }
    stage.setMaximized(true);
}
}