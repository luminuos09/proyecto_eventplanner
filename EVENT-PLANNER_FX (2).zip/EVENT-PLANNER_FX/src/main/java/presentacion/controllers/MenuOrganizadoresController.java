package presentacion.controllers;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;
import logica.GestorEventos;
import presentacion.NavigationHelper;

/**
 * Controlador para el menú de gestión de organizadores.
 * Permite acceder a las diferentes funcionalidades relacionadas con organizadores.
 * 
 * <p><b>Funcionalidades disponibles:</b></p>
 * <ul>
 *   <li>Registrar nuevo organizador</li>
 *   <li>Listar todos los organizadores</li>
 *   <li>Buscar organizador específico</li>
 * </ul>
 * 
 * <p><b>Patrón de navegación:</b></p>
 * Este controlador usa el Stage compartido para mantener una única ventana
 * en toda la aplicación, cambiando solo las escenas.
 * 
 * @author Ayner Jose Castro Benavides
 * @version 1.0
 * @since 2025-01-12
 */
public class MenuOrganizadoresController {
    
    /**
     * Instancia del gestor de eventos (patrón Singleton)
     */
    private GestorEventos gestor;
    
    /**
     * Stage principal de la aplicación (compartido)
     */
    private Stage stage;
    
    /**
     * Inicializa el controlador.
     * Se ejecuta automáticamente después de cargar el FXML.
     */
    @FXML
    public void initialize() {
        this.gestor = GestorEventos.getInstance();
        System.out.println("[MenuOrganizadores] Controlador inicializado");
    }
    
    /**
     * Establece el Stage principal de la aplicación.
     * 
     * @param stage El Stage compartido de la aplicación
     * 
     * <p><b>Importante:</b> Este método debe ser llamado inmediatamente
     * después de cargar el controlador para que la navegación funcione.</p>
     */
    public void setStage(Stage stage) {
        this.stage = stage;
        System.out.println("[MenuOrganizadores] Stage asignado: " + (stage != null));
    }
    
    // ==================== NAVEGACIÓN A FUNCIONALIDADES ====================
    
    /**
     * Abre el formulario para registrar un nuevo organizador.
     * 
     * <p><b>Flujo:</b></p>
     * <ol>
     *   <li>Carga el FXML del formulario</li>
     *   <li>Obtiene el controlador y le pasa el stage</li>
     *   <li>Cambia la escena actual a la del formulario</li>
     * </ol>
     */
    @FXML
    private void abrirFormularioOrganizador() {
        System.out.println("[MenuOrganizadores] Abriendo formulario de organizador...");
        
        if (this.stage == null) {
            mostrarError("Error", "No se puede abrir el formulario");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/FormularioOrganizador.fxml"));
            Parent root = loader.load();
            
            System.out.println("[MenuOrganizadores] FXML cargado correctamente");
            
            // Obtener el controlador y pasarle el stage
            FormularioOrganizadorController controller = loader.getController();
            if (controller != null) {
                controller.setStage(this.stage);
                System.out.println("[MenuOrganizadores] Stage asignado al formulario");
            } else {
                System.err.println("[MenuOrganizadores] Controlador es null");
            }
            
            Scene scene = new Scene(root);
            NavigationHelper.aplicarCSS(scene);
            
            this.stage.setScene(scene);
            this.stage.setTitle("Registrar Organizador - Event Planner");
            
            System.out.println("[MenuOrganizadores] Formulario abierto");
            
        } catch (IOException e) {
            System.err.println("[MenuOrganizadores] Error al abrir formulario:");
            mostrarError("Error", "No se pudo abrir el formulario: " + e.getMessage());
        }
    }
    
    /**
     * Muestra la lista de todos los organizadores registrados.
     */
    @FXML
    private void listarOrganizadores() {
        System.out.println("[MenuOrganizadores] Abriendo lista de organizadores...");
        
        if (this.stage == null) {
            mostrarError("Error", "No se puede abrir la lista");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/ListaOrganizadores.fxml"));
            Parent root = loader.load();
            
            ListaOrganizadoresController controller = loader.getController();
            if (controller != null) {
                controller.setStage(this.stage);
                System.out.println("[MenuOrganizadores] Stage asignado a lista");
            }
            
            Scene scene = new Scene(root);
            NavigationHelper.aplicarCSS(scene);
            
            this.stage.setScene(scene);
            this.stage.setTitle("Lista de Organizadores - Event Planner");
            
            System.out.println("[MenuOrganizadores] Lista mostrada");
            
        } catch (Exception e) {
            System.err.println("[MenuOrganizadores] Error al abrir lista:");
            e.printStackTrace();
            mostrarError("Error", "No se pudo abrir la lista: " + e.getMessage());
        }
    }
    
    /**
     * Abre la ventana de búsqueda de organizadores.
     */
    @FXML
    private void buscarOrganizador() {
        System.out.println("[MenuOrganizadores] Abriendo búsqueda de organizador...");
        
        if (this.stage == null) {
            mostrarError("Error", "No se puede abrir la búsqueda");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/BuscarOrganizador.fxml"));
            Parent root = loader.load();
            
            BuscarOrganizadorController controller = loader.getController();
            if (controller != null) {
                controller.setStage(this.stage);
                System.out.println("[MenuOrganizadores] Stage asignado a búsqueda");
            }
            
            Scene scene = new Scene(root);
            NavigationHelper.aplicarCSS(scene);
            
            this.stage.setScene(scene);
            this.stage.setTitle("Buscar Organizador - Event Planner");
            
            System.out.println("[MenuOrganizadores] Búsqueda abierta");
            
        } catch (Exception e) {
            System.err.println("[MenuOrganizadores] Error al abrir búsqueda:");
            e.printStackTrace();
            mostrarError("Error", "No se pudo abrir la búsqueda: " + e.getMessage());
        }
    }
    
    /**
     * Vuelve al menú principal de la aplicación.
     */
    @FXML
    private void volverMenuPrincipal() {
        System.out.println("[MenuOrganizadores] Volviendo al menú principal...");
        
        if (this.stage == null) {
            mostrarError("Error", "No se puede volver al menú");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/MenuPrincipal.fxml"));
            Parent root = loader.load();
            
            MenuPrincipalController controller = loader.getController();
            if (controller != null) {
                controller.setStage(this.stage);
            }
            
            Scene scene = new Scene(root);
            NavigationHelper.aplicarCSS(scene);
            
            this.stage.setScene(scene);
            this.stage.setTitle("Event Planner - Sistema de Gestión de Eventos");
            
            System.out.println("[MenuOrganizadores] Vuelto al menú principal");
            
        } catch (Exception e) {
            System.err.println("[MenuOrganizadores] Error al volver:");
            e.printStackTrace();
            mostrarError("Error", "No se pudo volver al menú principal");
        }
    }
    
    // ==================== MENSAJES AL USUARIO ====================
    
    /**
     * Muestra un mensaje de error al usuario.
     * 
     * @param titulo Título del diálogo de error
     * @param mensaje Mensaje descriptivo del error
     */
    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}