package presentacion.controllers;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import presentacion.NavigationHelper;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;


/**
 * Controlador del Menú Principal
 * 
 * @author Ayner Jose Castro Benavides
 * @version 1.0
 */
public class MenuPrincipalController {
    
    private Stage stage;
    
    /**
     * Establece el Stage principal
     * @param stage Stage principal de la aplicación
     */
    public void setStage(Stage stage) {
        this.stage = stage;
        System.out.println(" Stage recibido en MenuPrincipalController");
    }
    
    /**
     * Abre la gestión de eventos
     */
    @FXML
private void abrirGestionEventos() {
    System.out.println(" Abriendo Gestión de Eventos...");
    
    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/FormularioEvento.fxml"));
        Parent root = loader.load();
        
        //Critico: Obtiene el controlador

        FormularioEventoController controller = loader.getController();
        if(controller!=null){
            controller.setStage(this.stage);
            System.out.println("Stage asignado a MenuPrincipalController");
        }
        Scene scene = new Scene(root,900,700);
        NavigationHelper.aplicarCSS(scene);

        this.stage.setScene(scene);
        this.stage.setTitle("Ventana a la gestion de eventos");

        System.out.println("Ventana crear evento abierta");

        
    } catch (Exception e) {
        System.err.println(" Error al abrir Gestión de Eventos:");
        e.printStackTrace();
        mostrarError("Error", "No se pudo abrir el formulario de eventos: " + e.getMessage());
    }
}

    /**
     * Abre el menú de gestión de participantes
     */
    @FXML
    private void abrirGestionParticipantes() {
        System.out.println("Abriendo Gestión de Participantes...");
    
    if (stage == null) {
        System.err.println("ERROR: stage es null en MenuPrincipalController");
        mostrarError("Error", "Stage no inicializado");
        return;
    }

    try {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/fxml/MenuParticipantes.fxml"));
        Parent root = loader.load();
        
        System.out.println("MenuParticipantes.fxml cargado");
        
        // CRÍTICO: Obtener controlador y pasarle el stage
        MenuParticipantesController controller = loader.getController();
        
        if (controller != null) {
            controller.setStage(stage);  // ⬅️ Pasar el stage al controlador
            System.out.println("Stage asignado a MenuParticipantesController: " + (stage != null));
        } else {
            System.err.println("ERROR: MenuParticipantesController es null");
        }
        
        Scene scene = new Scene(root);
         // APLICAR CSS MORADO
        NavigationHelper.aplicarCSS(scene);
        stage.setScene(scene);
        stage.setTitle("Gestión de Participantes - Event Planner");
        
        System.out.println("Ventana de Gestión de Participantes mostrada");
        
    } catch (Exception e) {
        System.err.println("Error al abrir Gestión de Participantes:");
        e.printStackTrace();
        mostrarError("Error", "No se pudo abrir el menú de participantes: " + e.getMessage());
    }
    }

        /**
     * Abre el menú de gestión de organizadores
     */
    @FXML
    private void abrirGestionOrganizadores() {
        System.out.println("Abriendo Gestión de Organizadores...");
        
        if (this.stage == null) {
            mostrarError("Error", "No se puede abrir el menú");
            return;
        }
        
        try {
            FXMLLoader loader = new FXMLLoader(
                getClass().getResource("/fxml/MenuOrganizadores.fxml"));
            Parent root = loader.load();
            
            MenuOrganizadoresController controller = loader.getController();
            if (controller != null) {
                controller.setStage(this.stage);
            }
            
            Scene scene = new Scene(root);
            // NavigationHelper.aplicarCSS(scene);
            
            this.stage.setScene(scene);
            this.stage.setTitle("Gestión de Organizadores - Event Planner");
            
            System.out.println("Menú de Organizadores abierto");
            
        } catch (Exception e) {
            e.printStackTrace();
            mostrarError("Error", "No se pudo abrir el menú: " + e.getMessage());
        }
    }
            
        /**
         * Abre el menú del sistema de pagos
         */
        @FXML
        private void abrirSistemaPagos() {
            System.out.println("Abriendo Sistema de Pagos...");
            
            if (this.stage == null) {
                mostrarError("Error", "No se puede abrir el menú");
                return;
            }
            
            try {
                FXMLLoader loader = new FXMLLoader(
                    getClass().getResource("/fxml/MenuPagos.fxml"));
                Parent root = loader.load();
                
                MenuPagosController controller = loader.getController();
                if (controller != null) {
                    controller.setStage(this.stage);
                }
                
                Scene scene = new Scene(root);
                NavigationHelper.aplicarCSS(scene);
                stage.setMaximized(true);
                this.stage.setScene(scene);
                this.stage.setTitle("Sistema de Pagos - Event Planner");
                
                System.out.println("Sistema de Pagos abierto");
                
            } catch (Exception e) {
                e.printStackTrace();
                mostrarError("Error", "No se pudo abrir el sistema de pagos: " + e.getMessage());
            }
        }
    
    /**
     * Abre los reportes (próximamente)
     */
    @FXML
    private void abrirReportes() {
       System.out.println("Abriendo Reportes y Estadísticas...");
    
    if (this.stage == null) {
        mostrarError("Error", "No se puede abrir el menú");
        return;
    }
    
    try {
        FXMLLoader loader = new FXMLLoader(
            getClass().getResource("/fxml/MenuReportes.fxml"));
        Parent root = loader.load();
        
        MenuReportesController controller = loader.getController();
        if (controller != null) {
            controller.setStage(this.stage);
        }
        
        Scene scene = new Scene(root);
        this.stage.setScene(scene);
        stage.setMaximized(true);
        this.stage.setTitle("Reportes y Estadísticas - Event Planner");
        
        System.out.println("Reportes abiertos");
        NavigationHelper.aplicarCSSyMaximizar(scene, this.stage);
        
    } catch (Exception e) {
        e.printStackTrace();
        mostrarError("Error", "No se pudo abrir reportes: " + e.getMessage());
    }
    }
    
    /**
     * Sale de la aplicación con confirmación
     */
    @FXML
    private void salir() {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Salir");
        alert.setHeaderText("¿Está seguro que desea salir?");
        alert.setContentText("Se cerrará la aplicación Event Planner");
        
        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                System.out.println(" Cerrando aplicación...");
                System.exit(0);
            }
        });
    }
    
    // ============== MÉTODOS AUXILIARES ==============
    
    /**
     * Muestra un mensaje de error
     * @param titulo Título del diálogo
     * @param mensaje Mensaje del error
     */
    private void mostrarError(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
    
    /**
     * Muestra un mensaje informativo
     * @param titulo Título del diálogo
     * @param mensaje Mensaje informativo
     */
    private void mostrarInfo(String titulo, String mensaje) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
} 